#!/usr/bin/env python3
"""
Настройка системы V5 - Air Waffle
Реальные данные бизнеса - ВСЕ методы оплаты и категории
"""

from database_v5 import FinanceSystemV5

print("=" * 70)
print("  НАСТРОЙКА СИСТЕМЫ V5 - AIR WAFFLE")
print("=" * 70)

db = FinanceSystemV5()

# ========== 1. СЧЕТА ==========
print("\n💰 Создание счетов...")

# Касса
cash_id = db.add_account("Касса (наличные)", "cash")
print("  ✓ Касса (наличные)")

# РС счета (3 штуки)
rs1_id = db.add_account("YATT TUYKINA KLARA", "bank")
rs2_id = db.add_account("TATT YUSUPOV ALISHER", "bank")
rs3_id = db.add_account("OOO AIR WAFFLE", "bank")
print("  ✓ YATT TUYKINA KLARA")
print("  ✓ TATT YUSUPOV ALISHER")
print("  ✓ OOO AIR WAFFLE")

# ========== 2. МЕТОДЫ ОПЛАТЫ ==========
print("\n💳 Создание методов оплаты...")

# Массив РС для создания методов на каждый
rs_accounts = [
    (rs1_id, "YATT"),
    (rs2_id, "TATT"),
    (rs3_id, "OOO")
]

payment_methods_created = 0

for rs_id, rs_name in rs_accounts:
    # Терминалы (комиссия 0.2%)
    db.add_payment_method(f"Uzcard ({rs_name})", "terminal", 0.2, rs_id)
    db.add_payment_method(f"Humo ({rs_name})", "terminal", 0.2, rs_id)
    payment_methods_created += 2
    
    # Онлайн (комиссия 1%)
    db.add_payment_method(f"Click ({rs_name})", "online", 1.0, rs_id)
    db.add_payment_method(f"Payme ({rs_name})", "online", 1.0, rs_id)
    db.add_payment_method(f"Uzum Pay ({rs_name})", "online", 1.0, rs_id)
    payment_methods_created += 3
    
    # Доставки (разные комиссии)
    db.add_payment_method(f"Yandex Eats ({rs_name})", "delivery", 32.0, rs_id)
    db.add_payment_method(f"Uzum Tezkor ({rs_name})", "delivery", 32.0, rs_id)
    db.add_payment_method(f"Wolt ({rs_name})", "delivery", 26.0, rs_id)
    payment_methods_created += 3

print(f"  ✓ Создано {payment_methods_created} методов оплаты (по 8 на каждый РС)")

# ========== 3. ТОЧКИ ПРОДАЖ ==========
print("\n📍 Создание точек продаж...")

db.add_location("D&D Magic City", "ул. Бобура 174/14")
db.add_location("Выездные мероприятия", "Различные локации")
print("  ✓ D&D Magic City")
print("  ✓ Выездные мероприятия")

# ========== 4. КАТЕГОРИИ РАСХОДОВ ==========
print("\n📂 Создание категорий расходов...")

# FOOD COST
categories_created = 0

# Сырьё
raw_items = [
    "Юкки", "Колбаска Курин.", "Колбаски Говяж.", "Сосиска молочная", "Моцарелла",
    "Фарш для Гамбургеров", "Булочка", "Булочка для Гамбургеров", "Стрипсы ПФ",
    "Сыр чеддер", "Тортилья", "Фри", "Картофель деревенский", "Нагетсы",
    "Фритюрное масло", "Халапеньо", "Мука", "Яйцо", "Дрожжи", "Майонез",
    "Кетчуп", "Медово-горчичный", "Зернистая горчица", "Сырный соус",
    "Кукурузная мука", "Маринованные огурцы", "Разрыхлитель", "Молоко",
    "Рамен", "Рамен не острый", "Рамен острый", "Русская горчица",
    "Сливочный Сыр", "Соль", "Соус для Гамбургеров", "Соус Свит Чили",
    "Соус Янём", "Соевый соус", "Чесночный соус", "Сахар", "Помидоры",
    "Огурцы", "Айсберг", "Лук зеленый", "Лук репчатый", "Масло растительное",
    "Панировка", "Перец черный", "Печенька к кофе", "Кунжут", "Лимон",
    "Яблоко", "Апельсин", "Лайм", "Мята"
]

for item in raw_items:
    db.add_expense_category(item, "Сырьё и ингредиенты")
    categories_created += 1

print(f"  ✓ Сырьё: {len(raw_items)} категорий")

# Напитки
drinks_items = [
    "Кофе в зернах", "Каркаде (айс-ти)", "Чай черный", "Карамель-латте",
    "Какао", "Детский сок", "Лед", "Газированная вода", "Вода", "Сироп Ваниль",
    "Сахар (бар)", "Разлив Mirinda", "Разлив Pepsi", "Сироп Баринов",
    "Сироп Карамель", "Сок Апельсиновый", "Сок Гранатовый", "Спрайт", "Адреналин",
    "7 up", "Bliss", "Mirinda 0.5", "Вода 0.5", "Pepsi 0.25", "Pepsi 0.5", 
    "Pepsi 1L", "Lipton 0.5"
]

for item in drinks_items:
    db.add_expense_category(item, "Напитки")
    categories_created += 1

print(f"  ✓ Напитки: {len(drinks_items)} категорий")

# Упаковки
packaging_items = [
    "Лодочки", "Фри коробки", "Упаковка крафт для Гамбургеров", "Кидс Бокс",
    "Уголок для Гамбургеров", "Палка для корн дога", "Соусница", "Пергамент",
    "Бумага для лаваша", "Стаканчик Крафт", "Стаканчик Прозрачный",
    "Разлив стаканчик 0.3л", "Разлив стаканчик 0.4л", "Стаканчик для мороженого",
    "Трубочка", "Влажные салфетки", "Салфетки"
]

for item in packaging_items:
    db.add_expense_category(item, "Упаковка и расходники")
    categories_created += 1

print(f"  ✓ Упаковка: {len(packaging_items)} категорий")

# LABOR COST
db.add_expense_category("Зарплата сотрудников", "Зарплаты")
db.add_expense_category("Подработка/сдельная оплата", "Зарплаты")
categories_created += 2
print("  ✓ Зарплаты: 2 категории")

# OVERHEAD
db.add_expense_category("Аренда", "Постоянные расходы")
db.add_expense_category("Коммунальные (электричество, газ, вода)", "Постоянные расходы")
db.add_expense_category("Ремонт и расходники (моющие средства)", "Постоянные расходы")
db.add_expense_category("IT/сервисы (касса, ПО, интернет)", "Постоянные расходы")
db.add_expense_category("Отмены заказов", "Постоянные расходы")
db.add_expense_category("Прочие расходы", "Постоянные расходы")
categories_created += 6
print("  ✓ Постоянные расходы: 6 категорий")

print(f"\n  📊 ВСЕГО КАТЕГОРИЙ: {categories_created}")

# ========== ИТОГИ ==========
print("\n" + "=" * 70)
print("  ✅ НАСТРОЙКА ЗАВЕРШЕНА!")
print("=" * 70)

balances = db.get_account_balance()

print(f"\n💰 БАЛАНСЫ СЧЕТОВ:")
for acc_id, data in balances.items():
    acc_emoji = "💵" if data['type'] == 'cash' else "🏦"
    print(f"  {acc_emoji} {data['name']}: {data['balance']:,.0f} сум")

print(f"\n📊 СОЗДАНО:")
print(f"  Счетов: {len(db.get_accounts())}")
print(f"  Методов оплаты: {len(db.get_payment_methods())}")
print(f"  Точек продаж: {len(db.get_locations())}")
print(f"  Категорий расходов: {categories_created}")

print("\n" + "=" * 70)
print("  🎉 СИСТЕМА ГОТОВА К РАБОТЕ!")
print("=" * 70)
print("\nЗапустите GUI приложение:")
print("  python3 main_app.py")
print("\nИли Telegram бота:")
print("  python3 telegram_bot_simple.py")
print("=" * 70)

db.close()

